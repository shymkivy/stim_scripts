To interface with other devices while running an ABR, the RZ6 can send out TTL pulses associated with each stimulus. 
SGRZ_Std_200K_wBitOut.rcx uses the trigger line that tells BioSigRZ when to stimulate and also sends this signal from the BitOut with a BitMask=2. 
This trigger will remain high for the duration of the stimulus window in SigGenRZ, but with the addition of an EdgeDetect and a Schmitt you could make this trigger a different length if desired. 

Root_ToneAbr_wTTLOut.acf will automatically target SGRZ_Std_200K_wBitOut.rcx, or you can use an existing .acf file you may have and target SGRZ_Std_200K_wBitOut.rcx by launching BioSigRZ, selecting File from the tool bar > Target Device > Then map to SGRZ_Std_200K_wBitOut.rcx in the Name field. 

SGRZ_Std_200K_wBitOut.rcx must be placed in the C:\TDT\BioSigRZ\Configs\ABR folder. 