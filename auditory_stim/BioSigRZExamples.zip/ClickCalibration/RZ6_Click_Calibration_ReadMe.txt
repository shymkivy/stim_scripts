The RZ6_Click_Calibration.rcx circuit is designed to allow users to calibrate their RZ6 for click stimuli.
To use this circuit there are a few steps required for setup:
1) Connect your Calibration Microphone to the In-A port on the RZ6
2) Be sure your Amp/BYP switch on the faceplate of the RZ6 is set to AMP if your microphone has a sensitivity under 50 mV/PA
3) Connect your speaker to Out-A  or Electrostatic-A (if using Electrostatic-A, be sure the Electrostatic On/Off switch is in the On position)
4) In the circuit, double-click the 'dBSPL' macro to adjust the Microphone Amplification level to match the Gain knob on your RZ6. Typically 40-60dB works well for this if your microphone has 1-3 mV/PA sensitivity. If you are bypassing the amplifier, this gain should be set to 1.  
5) Also in the dBSPL macro, set the Microphone Sensitivity to match the sensitivity of your microphone.
6) Place your microphone in the same position that your subject�s ear would be located. 

To run this circuit:
A) Click the "Compile, Load, and Run" button on the top tool bar. 
B) Start with a low voltage in your "click amplitude (V)" ConstF and slowly increase this value. 
C) When the dBSPL level shown on the right of the screen matches your desired level, make a note of the voltage you are using. 
D) This voltage and the corresponding level should be entered in the Signal Parameters window in SigGen (SigGenRZ > Modify > Signal) 
E) Save the .sig file with this ratio entered. 
F) Run the stimulus file in BioSigRZ without a calibration (.tcf) file applied to the stimulus. Your stimulus is already calibrated, and adding a .tcf file will cause the calibration to be off.    
